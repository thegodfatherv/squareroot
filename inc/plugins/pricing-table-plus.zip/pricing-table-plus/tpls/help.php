<div class="wrap">
<div class="icon32 icon32-posts-post" id="icon-edit"><br></div>
<h2 class="nav-tab-wrapper">How to use Pricing Table Plus <a style="color: #008000;" class="nav-tab" href="http://wpeden.com/product/wordpress-pricing-table-plus-plugin-pro/">Get pro version with 50+ diff templates</a></h2>

<Br/>

Follow the steps to create wordpress Pricing Table Plus:
<ol>
       
    <li>Now just click on "add new" and you will see the form:<br/>
<a href="<?php echo plugins_url('/pricing-table-plus'); ?>/images/add-new-pricing-table-plus.png"><img class="alignnone size-full wp-image-125" title="Add new Pricing Table Plus - wordpress Pricing Table Plus plugin" src="<?php echo plugins_url('/pricing-table-plus'); ?>/images/add-new-pricing-table-plus.png" alt="Add new Pricing Table Plus - wordpress Pricing Table Plus plugin" width="720" height="463" /></a>
<br/>Now You first add a title for Pricing Table Plus, then click on add package button. You'll see a popup like the following image:<br/>
<a href="<?php echo plugins_url('/pricing-table-plus'); ?>/images/1.jpg"><img class="size-full wp-image-126  alignnone" title="Add new Package - WordPress Pricing Table Plus Plugin" src="<?php echo plugins_url('/pricing-table-plus'); ?>/images/1.jpg" alt="Add new Package - WordPress Pricing Table Plus Plugin" width="521" height="301" /></a><br/>Enter a package title and click ok and follow the same way for package. After you add some packages and features it'll look something like following image:
<a href="<?php echo plugins_url('/pricing-table-plus'); ?>/images/add-new-pricing-table-plus-1.png"><img class="alignnone size-full wp-image-127" title="Add new Pricing Table Plus - WordPress Pricing Table Plus Plugin" src="<?php echo plugins_url('/pricing-table-plus'); ?>/images/add-new-pricing-table-plus-1.png" alt="Add new Pricing Table Plus - WordPress Pricing Table Plus Plugin" width="1018" height="627" /></a></li>
    <li>Set feature values for each package yes, no, limited, not applicable or whatever it is</li>
    <li>Click on publish button and you just finished creating a Pricing Table Plus.</li>
    <li>Now use the shortcode <strong>[</strong>pricing-table-plus id=table_id_you_just_create template=template_name<strong>]</strong> inside page or post content to show your Pricing Table Plus and it will look like this:
<a href="<?php echo plugins_url('/pricing-table-plus'); ?>/images/pricing-table-plus-preview.png"><img class="alignnone size-full wp-image-128" title="WordPress Pricing Table Plus Preview" src="<?php echo plugins_url('/pricing-table-plus'); ?>/images/pricing-table-plus-preview.png" alt="WordPress Pricing Table Plus Preview" width="970" height="577" /></a></li>
<li>2 template available here: (1) <code>green</code> (2) <code>gray</code></li>
    
</ol>
 
Also a similar plugin with <strong>15</strong> different theme available <strong><a title="WordPress Pricing Table Plus Plugin Pro" href="http://wpeden.com/product/wordpress-pricing-table-plus-plugin-pro/">here</a></strong>.

</div>